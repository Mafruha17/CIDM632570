from django.apps import AppConfig


class HallucinationAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hallucination_app'
